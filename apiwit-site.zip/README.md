# Apiwit Triwatana — personal site

Static one-page portfolio (no build step). Files:

- `index.html` — the whole site
- `assets/Apiwit_Triwatana_CV.pdf` — CV linked from the site
- `assets/img/` — project slides

## Publish on GitHub Pages (5 minutes)

1. Sign in at github.com. Click **+ → New repository**.
2. Name it exactly **`<your-github-username>.github.io`** (e.g. `apiwit-triwatana.github.io`). Public. Create.
3. Click **uploading an existing file**, drag in everything from this folder (index.html, README.md, .nojekyll, and the `assets` folder). Commit.
4. Go to **Settings → Pages**. Source: *Deploy from a branch*, Branch: `main`, folder `/ (root)`. Save.
5. After ~1 minute the site is live at `https://<your-github-username>.github.io`.

## Updating

- New CV: replace `assets/Apiwit_Triwatana_CV.pdf` with the same file name.
- Edit text: open `index.html` on GitHub, click the pencil icon, commit.
